## ChromeDriverのパス
CHROME_DRIVER_PATH = u'c:/driver/chromedriver.exe'

## DBファイルのパス
SQLITE3_DB_FILE = u'./poleBlog.db'

## 画像ファイルの保存先
IMAGE_PATH = u'./images'

## ログファイルのパス
LOG_FILE_PATH = u'./log/poleBlog.log'

#ImageMagickのパス
CMD_IMAGEMAGICK = u'C:\Program Files\ImageMagick-7.0.10-Q16-HDRI\magick.exe'
