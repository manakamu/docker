## @package poleblog
#
#  ポーラブログ特有機能のパッケージ
#

import os
import time
from datetime import datetime

import lxml.html

from sqlite3dao import Sqlite3Dao
from webcrawler import WebCrawler
from webimage import WebImage

## ブログ記事の日付の形式（形式の変換に必要）
BLOG_DATE_FORMAT = u'%Y-%m-%d %H:%M:%S'

## ポーラブログDBアクセス機能のクラス
#  @remarks Sqlite3Daoからの派生クラス
#
class poleBlogDao(Sqlite3Dao):
    ## コンストラクタ
    #  @param   self                [in]    The object pointer.
    #  @param   log_file            [in]    ログファイルオブジェクト
    #  @param   db_file_path        [in]    SQLite3のDBファイルのパス
    #  @param   db_isolation_level  [in]    DBの排他モード
    #  @remarks 親クラスのコストラクタをコールすること
    #
    def __init__(self, log_file, db_file_path, db_isolation_level):
        log_file.log_function(u'Enter')

        self.__log_file = log_file

        # 継承元クラスのコンストラクタをコールする
        super().__init__(log_file, db_file_path, db_isolation_level)

        self.__log_file.log_function(u'Leave')

    ## デストラクタ
    #  @param   self    [in]    The object pointer.
    #  @remarks 親クラスのデストラクタをコールすること
    #
    def __del__(self):
        self.__log_file.log_function(u'Enter')

        # 継承元クラスのデストラクタをコールする
        super().__del__()

        self.__log_file.log_function(u'Leave')

    ## テーブル作成処理
    #　ポーラブログ用DBのテーブルを作成する。
    #  @param   self    [in]    The object pointer.
    #　@remarks テーブルの生成中にエラーが発生したら、DBをロールバックする。
    #
    def create_db_table(self):
        self.__log_file.log_function(u'Enter')
        try:
            # トランザクションを開始する
            self.begin_transaction()

            row_list = [
                u'girlId integer primary key autoincrement',
                u'name text unique not null',
                u'lastUpdate datetime not null'
            ]
            self._create_table(u'T_girl', row_list)

            row_list = [
                u'girlsListId integer primary key autoincrement',
                u'blogId integer',
                u'girlId integer not null',
                u'foreign key(girlId) references T_girl(girlId) on delete cascade on update cascade',
                u'foreign key(blogId) references T_blog(blogId) on delete cascade on update cascade'
            ]
            self._create_table(u'T_girlsList', row_list)

            row_list = [
                u'imageId integer primary key autoincrement',
                u'url text not null',
                u'filePath text not null',
                u'blogId integer',
                u'foreign key(blogId) references T_blog(blogId)  on delete cascade on update cascade'
            ]
            self._create_table(u'T_image', row_list)

            row_list = [
                u'blogId integer primary key autoincrement',
                u'date datetime not null',
                u'title text',
                u'contents text not null',
                u'url text not null',
                u'notified integer default 0',
            ]
            self._create_table(u'T_blog', row_list)

            self._conn.execute(
                u'create unique index if not exists I_blog on T_blog(date)')

            row_list = [
                u'id integer primary key',
                u'date datetime not null',
                u'log integer not null',
                u'detail text',
                u'blogId integer',
            ]
            self._create_table(u'T_log', row_list)

            row_list = [
                u'mail_address text primary key',
                u'notification integer',
                u'favorite_girls text',
                u'update_date datetime not null',
            ]
            self._create_table(u'T_mail', row_list)

            # コミットする
            self.commit()

        except Exception as e:
            # ロールバックする
            self.rollback()

            errorText = u''
            for arg in e.args:
                errorText += arg  
            self.__log_file.log_fatal(errorText)
            raise e

        self.__log_file.log_function(u'Leave')

    ## T_girlテーブル更新処理
    #　T_girlにレコードを追加する。
    #  @param   self        [in]    The object pointer.
    #  @param   date        [in]    日付
    #  @param   girls_list  [in]    女の子リスト
    #
    def update_girl_table(self, date, girls_list):
        self.__log_file.log_function(u'Enter')
        self.__log_file.log_info(u'date:{} girlsList:{}'.\
            format(date.text, u', '.join(girls_list))
        )

        girls = []
        for girl in girls_list:
            if self._get_count__(u'T_girl', u"name = '{}'".format(girl)) == 0:
                # DBに同一名がない場合のみ登録する
                girls.append((girl, date.text))
            else:
                # DBにある場合は最終更新日を更新する(DBの最終更新日<引数で指定された日時の場合)
                cursor = self._conn.cursor()
                sql = u"update T_girl set lastUpdate = datetime('{0}') where name = '{1}' \
                        and (select datetime(lastUpdate) from T_girl where name = '{1}') < datetime('{0}')".format(
                        date.text, girl
                    )
                cursor.execute(sql)

        if len(girls) > 0:
            self._insert_columnToDB(u'T_girl(name, lastUpdate)', girls)

        self.__log_file.log_function(u'Leave')
 
    ## ブログ記事の登録済み確認処理
    #　引数で指定された日付のブログ記事がDBにあるか確認する。
    #  @param   self        [in]    The object pointer.
    #  @param   date        [in]    ブログ記事を探す日付
    #  @return True:DBにある、False：DBにない
    #
    def is_article_exist_on_db(self, date):
        self.__log_file.log_function(u'Enter')

        is_already_stored = False
        if self._get_count__(u'T_blog', u"date = '{}'".format(date.text)) > 0:
            is_already_stored = True

        self.__log_file.log_function(u'Leave')
        return is_already_stored

    ## T_girlsListテーブル更新処理
    #　T_girlsListにレコードを追加する。
    #  @param   self        [in]    The object pointer.
    #  @param   blog_id     [in]    元となるブログ記事のId
    #  @param   girls       [in]    女の子リスト（list）
    #  @return  登録したレコードのgirlsListId
    #
    def update_girls_list(self, blog_id, girls):
        self.__log_file.log_function(u'Enter')

        girls_list_id = None
        cursor = self._conn.cursor()
        for girl in girls:
            cursor.execute(u'insert into T_girlsList(blogId, girlId) \
                values(? , (select girlId from T_girl where name = ?))', \
                (blog_id, girl))
            self.__log_file.log_info(u'blogId:{} girl:{}'.format(blog_id, girl))
        
        self.__log_file.log_function(u'Leave')
        return girls_list_id

    ## T_imageテーブル更新処理
    #　T_imageにレコードを追加する。
    #  @param   self            [in]    The object pointer.
    #  @param   image_file_list [in]    画像ファイルの情報（urlとパスのtupleのlist）
    #
    def update_image_table(self, image_file_list):
        self.__log_file.log_function(u'Enter')
        if len(image_file_list) == 0:
            self.__log_file.log_warning(u'Length of image_file_list is zero.')
            return

        self._insert_columnToDB(u'T_image(blogId, url, filePath)', image_file_list)

        self.__log_file.log_function(u'Leave')

    ## T_blogテーブル更新処理
    #　T_blogにレコードを追加する。
    #  @param   self            [in]    The object pointer.
    #  @param   date_time       [in]    ブログ記事の日時
    #  @param   title           [in]    ブログ記事のタイトル
    #  @param   contents        [in]    ブログ記事の内容
    #  @param   url             [in]    ブログ記事のURL
    #  @return  追加した記事のBlogId
    #
    def update_blog_table(self, date_time, title, contents, url):
        self.__log_file.log_function(u'Enter')
        self.__log_file.log_info(
            u'dateTime:{} title:{} url:{}'.format(
            date_time.text, title, url))

        self._insert_columnToDB(
            u'T_blog(date, title, contents, url)',
            [(date_time.text, title, contents, url)]
        )

        # 追加したレコードのblogId（自動連番）を取得する
        cursor = self._conn.cursor()
        cursor.execute(
            u'select * from T_blog where rowid = last_insert_rowid()'
            )
        blog_id = 0
        for row in cursor:
            blog_id = row[u'blogId']

        self.__log_file.log_function(u'Leave')
        return blog_id

    ## 未通知のブログ記事検索処理
    #　引数で指定された期間のT_blogのnotify=0のレコード（最新1件）を検索する。
    #  @param   self            [in]    The object pointer.
    #  @param   date_time_from  [in]    検索期間（開始）
    #  @param   date_time_to    [in]    検索期間（終了）
    #  @return  result:True：未通知の記事あり、False:未通知の記事なし@n
    #           date：未通知の記事の日時@n
    #           blog_id：未通知の記事のblog_id@n
    #           title：未通知の記事のタイトル@n
    #           contents：未通知の記事の内容@n
    #           girls_list：未通知の記事の女の子リスト
    #
    def find_unnotified_article(self, date_time_from, date_time_to):
        self.__log_file.log_function(u'Enter')

        result = False
        cursor = self._conn.cursor()

        # 未通知の最新の1件のブログ記事のblogIdを取得する
        cursor.execute(
            u'select blogId, date, title, contents from T_blog \
            where date between datetime(?) and datetime(?) and \
            notified = 0 order by date desc limit 1',
            (date_time_from, date_time_to))

        date = u''
        blog_id = u''
        title = u''
        contents = u''
        girls_list = []
        for row in cursor: # SQLでlimit 1 しているため1件しかないはず
            date = row[u'date']
            blog_id = row[u'blogId']
            title = row[u'title']
            contents = row[u'contents']
            
            self.__log_file.log_info(u'date:{} blogId:{}'.format(
                date, blog_id))
            
            # 未通知の最新の1件のブログ記事の女の子リストを取得
            sql = u"select name from T_girl, T_girlsList \
                where T_girl.girlId = T_girlsList.girlId and T_girlsList.blogId = '{}'".format(blog_id)
            cursor.execute(sql)
            for row in cursor:
                girls_list.append(row[u'name'])
            result = True

            self.__log_file.log_info(u'girlsList:{}'.format(u', '.join(girls_list)))

        self.__log_file.log_function(u'Leave')
        return result, date, blog_id, title, contents, girls_list

    ## 画像のURLリスト取得処理
    #　引数で指定されたブログ記事のidから、その記事の画像一覧を取得する。
    #  @param   self        [in]    The object pointer.
    #  @param   blog_id     [in]    ブログ記事のblog_id
    #  @return 画像のURLリスト
    def getImageUrlsFromBlogId(self, blog_id):
        self.__log_file.log_function(u'Enter')

        cursor = self._conn.cursor()

        image_url_list = []
        # 指定されたblogIdの画像URLをDBから取得する
        sql = u"select url from T_image where blogId ='{}'".format(blog_id)
        cursor.execute(sql)
        for row in cursor:
            url = row['url']
            image_url_list.append(url)
            self.__log_file.log_info(u'url:{}'.format(url))
        
        self.__log_file.log_function(u'Leave')
        return image_url_list

    ## メール通知済みフラグ設定処理
    #  指定されたblogIdの記事のメール通知済みフラグをセットする。
    #  @param   self        [in]    The object pointer.
    #  @param   blog_id     [in]    ブログ記事のblogId
    #
    def setNotifiedFlag(self, blog_id):
        self.__log_file.log_function(u'Enter')

        try:
            cursor = self._conn.cursor()
            self.begin_transaction()
            sql = u"update T_blog set notified = 1 \
                where blogId = '{}'".format(blog_id)
            cursor.execute(sql)
            self.commit()

        except Exception as e:
            self.rollback()
            errorText = u''
            for arg in e.args:
                errorText += arg  
            self.__log_file.log_fatal(errorText)
            raise e

        self.__log_file.log_function(u'Leave')

    ## 女の子名全取得処理
    #  T_girlにある全女の子の名前を取得する
    #  @param   self    [in]    The object pointer.
    #  @return  女の子の名前リスト（list）
    #
    def getAllGirlsName(self):
        self.__log_file.log_function(u'Enter')

        girls_name_list = []
        cursor = self._conn.cursor()
        cursor.execute(u'select name from T_girl')
        for row in cursor:
            girls_name_list.append(row['name'])

        self.__log_file.log_function(u'Leave')
        return girls_name_list

    ## 通知メールアドレス全取得処理
    #  T_mailにあるメールアドレスを取得する
    #  @param   self    [in]    The object pointer.
    #  @return  メールアドレスと推し（tupleのlist）
    #
    def get_mail_list(self):
        self.__log_file.log_function(u'Enter')

        cursor = self._conn.cursor()
        cursor.execute(u'select * from T_mail')
        mail_list = []
        for row in cursor:
            mail_address = row['mail_address']
            favorite_girls = row['favorite_girls']
            # listが文字列としてDBに保存されるため、数値のリストに変換する
            girls_ids = favorite_girls.strip('[]')
            girl_id_list = []
            if len(girls_ids) > 0:
                girl_id_list = girls_ids.split(',')
                girl_id_list = [int(id.strip("' ")) for id in girl_id_list]

                # DBから女の子の名前を取得する
                where_phrase = u''
                index = 0
                for girl_id in girl_id_list:
                    where_phrase += str(girl_id)
                    index += 1
                    if index < len(girl_id_list):
                        where_phrase += u','
                sql = u'select name from T_girl where girlId in ({})'.format(where_phrase)
                cursor.execute(sql)

                girls_name_list = []
                for row in cursor:
                    girls_name_list.append(row['name'])
            mail_list.append((mail_address, girls_name_list))

        self.__log_file.log_function(u'Leave')
        return mail_list

    ## ログ処理
    #  T_logに動作ログを保存する。
    #  @param   self    [in]    The object pointer.
    #  @param   log     [in]    ログの内容(0:Check start/1:Check end/2:Sent mail)
    #  @param   detail  [in]    ログの詳細(あれば)
    #  @param   blog_id [in]    ブログ記事のBlogId(あれば)
    #
    def write_log_to_db(self, log, detail = None, blog_id = None):
        date = u"{0:%Y-%m-%d %H:%M:%S.%f}".format(datetime.now())
        self._insert_columnToDB(u'T_log(date, log, detail, blogId)',
            [(date, log, detail, blog_id)])
        self.commit()

    ## ログ削除処理
    #  指定された日時より古いログを、T_logから削除する。
    #  @param   self    [in]    The object pointer.
    #  @param   date    [in]    削除するログの日時（指定より古いログを削除する）
    #
    def cleanup_log(self, date):
        self.__log_file.log_function(u'Enter')

        sql = u"delete from T_log where datetime(date) < datetime('{}')".format(date)
        cursor = self._conn.cursor()
        cursor.execute(sql)
        self.commit()

        self.__log_file.log_function(u'Leave')

## ポーラブログ巡回機能クラス
#  @remarks WebCrawlerからの派生クラス
#
class poleBlogCrawler(WebCrawler):
    ## DBに保存する日付の形式（ソートの都合上形式を統一する）
    DB_DATE_FORMAT = u'{0:%Y-%m-%d %H:%M:%S}'

    ## コンストラクタ
    #  @param   self                            [in]    The object pointer.
    #  @param   log_file                        [in]    ログファイルオブジェクト
    #  @param   chrom_driver_path               [in]    ChromeDriveのパス
    #  @param   crawl_delay                     [in]    巡回遅延時間
    #  @param   girls_name_pattern              [in]    ブログ記事から女の子の名前を探すパターン
    #  @param   girls_name_delimiter            [in]    ブログ記事中の女の子の名前の区切り文字
    #  @param   image_file_dir                  [in]    画像を保存するフォルダ
    #  @param   image_file_extension_to_save    [in]    保存する画像の拡張子
    #  @remarks 保存する画像の拡張子は、不要な画像（PNGやGIFのアイコン等）を保存しないように指定する。@n
    #           親クラスのコストラクタをコールすること。
    #
    def __init__(
        self, log_file, chrom_driver_path, crawl_delay, girls_name_pattern,
        girls_name_delimiter, image_file_dir, image_file_extension_to_save):
        
        log_file.log_function(u'Enter')

        # 継承元クラスのコンストラクタをコールする
        super().__init__(log_file, chrom_driver_path, crawl_delay)
        self.__log_file = log_file
        self.__girls_name_pattern = girls_name_pattern
        self.__girls_name_delimiter = girls_name_delimiter
        self.__image_file_extension_to_save = image_file_extension_to_save
        self.__image_file_dir = image_file_dir

        log_file.log_function(u'Leave')

    ## デストラクタ
    #  @param   self    [in]    The object pointer.
    #  @remarks 親クラスのデストラクタをコールすること。
    #
    def __del__(self):
        self.__log_file.log_function(u'Enter')

        # 継承元クラスのデストラクタをコールする
        super().__del__()

        self.__log_file.log_function(u'Leave')

    ## 記事の日付の一覧取得処理
    #  @details 記事の一覧から記事の日付の一覧を取得する
    #  @param   self    [in]    The object pointer.
    #  @param   html    [in]    ブログ記事一覧のHTML
    #  @return dates:ブログ記事の日付一覧(list)
    #          index_to_skip：スキップする日付の一覧（list）
    #  @remarks 会員限定の記事は取得できない。@n
    #           datesの内、会員限定の記事のIndexをindex_to_skipに返す。
    #
    def __get_blog_article_dates(self, html):
        self.__log_file.log_function(u'Enter')

        index_to_skip = []
        dates = html.cssselect(u'p.skin-textQuiet')
        index  = 1
        for date in dates:
            # ブログ記事の日付の形式を変換する
            if not date.text:
                # New!が付いているとcss selectorで日付を取得できないため、xpathで探す
                self.__log_file.log_warning(u'date is null.')
                date_loud = html.xpath(
                    u'//*[@id="main"]/div[1]/div[2]/ul/li[{}]/div/div[2]/div/p/text()'.\
                    format(index))
                date.text = date_loud[0]
            else:
                # シークレットな記事かどうかチェックする（spanを探す）
                isSecret = html.xpath(
                    u'//*[@id="main"]/div[1]/div[2]/ul/li[{}]/div/div[2]/h2/a/span'.\
                    format(index))
                if not isSecret:
                    date.text = self.DB_DATE_FORMAT.format(
                        datetime.strptime(date.text, BLOG_DATE_FORMAT))
                else:
                    index_to_skip.append(index - 1)
                    # シークレットな記事は取得できないため除外する
                    self.__log_file.log_warning(u'Secret article found. {} skipped.'.\
                        format(self.DB_DATE_FORMAT.\
                        format(datetime.strptime(date.text, BLOG_DATE_FORMAT))))
            index += 1
            self.__log_file.log_info(u'date.text:{}'.format(date.text))

        self.__log_file.log_function(u'Leave')
        return dates, index_to_skip

    ## 記事のリンクの一覧取得処理
    #  @details 記事の一覧から各記事のリンクの一覧を取得する
    #  @param   self    [in]    The object pointer.
    #  @param   html    [in]    ブログ記事一覧のHTML
    #  @return  links   ブログ記事のリンク一覧（list）
    #
    def __get_blog_article_links(self, html):
        self.__log_file.log_function(u'Enter')

        links = html.cssselect(u'li.skin-borderQuiet h2 a')
        for link in links:
            self.__log_file.log_info(u'link:{}'.format(link.attrib[u'href']))

        self.__log_file.log_function(u'Leave')
        return links

    ## 記事の本文取得処理
    #  @details 引数で指定されたURLからブログ記事本文を取得する
    #  @param   self    [in]    The object pointer.
    #  @param   url     [in]    ブログ記事のURL
    #  @return  title:ブログ記事のタイトル@n
    #           text:ブログ記事の本文@n
    #           image_urls:ブログ記事内の画像のURL(list)
    #  @remarks ブログ記事本文は、空白行を除いて返す。
    #
    def __get_pole_blog_contents(self, url):
        self.__log_file.log_function(u'Enter')

        # HTMLをParse
        html = self._get_html(url)

        # タイトルを取得
        title = u''
        aList = html.cssselect(u'a.skinArticleTitle')
        if len(aList) > 0:
            title = aList[0].text

        text = u''
        # 本文を取得
        contents = html.cssselect(
            u'article div.skin-entryInner #entryBody div')
        if not contents:
            contents = html.cssselect(
                u'article div.skin-entryInner #entryBody > div')
            if not contents:
                contents = html.cssselect(
                    u'article div.skin-entryInner #entryBody > p')

        for element in contents:
            if element.text != None:
                self.__log_file.log_debug(u'element.text:{}'.format(element.text))
                # 不要な前後のスペースや改行を削除する
                strippedText = element.text.strip()
                if len(strippedText) > 0:
                    # 不要なdivは除いて、本文を改行を付けて結合する
                    text += strippedText + u'\n'

        if not text:
            contents = html.cssselect(u'article div.skin-entryInner #entryBody')[0]
            text = contents.text_content()
            lines = text.split(u'\n')
            text = u''
            # 不要な改行を削除する
            for line in lines:
                if len(line.strip()) > 0:
                    text += line.strip() + u'\n'

        image_urls = []
        # 画像のURLを取得
        images = html.cssselect(u'article div.skin-entryInner #entryBody img')
        for img in images:
            imageg_url = img.attrib[u'src']
            image_urls.append(imageg_url)
            self.__log_file.log_info(u'imageg_url:{}'.format(imageg_url))

        self.__log_file.log_function(u'Leave')
        return title, text, image_urls

    ## 女の子リスト取得処理
    #  @details ブログ記事の本文から、記事から女の子リストを取得する。
    #  @param   self    [in]    The object pointer.
    #  @param   text    [in]    ブログ記事の本文
    #  @return  女の子の名前一覧（list）
    #
    def _get_girls(self, text):
        self.__log_file.log_function(u'Enter')

        # 女の子リストを抽出
        extracted_girls = self.__girls_name_pattern.findall(text)#self.__girls_name_pattern.findall(text)
        girls_list = []
        for girls in extracted_girls:
            l = girls.split(u'☆')
            for girl in l:
                if len(girl) > 0:
                    girls_list.append(girl)

        self.__log_file.log_info(u'girls_list:{}'.format(u', '.join(list(girls_list))))

        self.__log_file.log_function(u'Leave')
        return girls_list

    ## 画像保存処理
    #  @details 指定されたURLの画像をファイルに保存する。
    #  @param   self        [in]    The object pointer.
    #  @param   blog_id     [in]    元となるブログ記事のBlogId
    #  @param   image_urls  [in]    画像のURL(list)
    #  @return  URLとローカルの画像ファイルパスのリスト（tupleのlist）
    #
    def __save_pole_blog_image_to_file(self, blog_id, image_urls):
        self.__log_file.log_function(u'Enter')
        
        saved_image_file_list = []
        web_image = WebImage(self.__log_file)
        for image_url in image_urls:
                image_file_name = web_image.get_image_file_name(image_url)
                image_file_path = os.path.join(self.__image_file_dir, image_file_name)
                # 指定された拡張子のみ保存する
                if web_image.get_image_file_extension(image_url) \
                    in self.__image_file_extension_to_save:
                    # 既に同名のファイルがある場合は保存しない
                    if not os.path.exists(image_file_path):
                        web_image.save_image(image_url, image_file_path)
                    saved_image_file_list.append((blog_id, image_url, image_file_path))
                    self.__log_file.log_info(
                        u'blog_id:{} image_url:{} image_file_path:{}'.\
                            format(blog_id, image_url, image_file_path)
                    )
                else:
                    self.__log_file.log_debug(u'Saving {} skipped.'.format(image_file_name))
        
        self.__log_file.log_function(u'Leave')
        return saved_image_file_list

    ## 次のページ取得処理
    #  @details ブログ記事の一覧から、次のページのURLを取得する。
    #  @param   self        [in]    The object pointer.
    #  @param   base_url    [in]    ブログ記事一覧のURL
    #  @param   html        [in]    ブログ記事一覧のHTML
    #  @return  次の一覧ページのURL
    #  @remarks ブログ記事一覧のアクティブなボタン（現在のページ）の次のページのURLを返す。
    #    
    def get_next_page_url(self, base_url, html):
        self.__log_file.log_function(u'Enter')

        next_index = 0
        url = ''
        # 次のページのボタンを検索
        next_buttons = html.cssselect(u'ul.skin-paginationNums li a.skin-btnIndex')
        for next_button in next_buttons:
            if next_button.attrib[u'class'] == u'skin-btnIndex is-active':
                # アクティブなボタン
                next_index = int(next_button.text) + 1
            else:
                # アクティブでないボタン
                if int(next_button.text) == next_index:
                    url = self._convert_relative_url_to_absolute_url(
                        base_url, next_button.attrib[u'href'])
                    break

        self.__log_file.log_info(u'url:{}'.format(url))
        self.__log_file.log_function(u'Leave')
        return url

    ## ポーラブログ保存処理
    #  @details ポーラブログを最新の記事からリンクを辿って保存する。
    #  @param   self            [in]    The object pointer.
    #  @param   dao             [in]    SQLITE3のDAOオブジェクト
    #  @param   start_url       [in]    保存開始URL
    #  @param   is_save_image   [in]    画像を保存するかのフラグ（True：保存する、False：保存しない）
    #
    def save_pole_blog(self, dao, start_url, is_save_image):
        self.__log_file.log_function(u'Enter')

        url = start_url
        do_loop = True

        while do_loop:
            # HTMLを取得
            html = self._get_html(url)

            # 日時を取得
            date_index = 0
            dates, index_to_skip = self.__get_blog_article_dates(html)

            # linkを取得
            links = self.__get_blog_article_links(html)

            index = 0
            # リンクを辿って本文を取得
            for a in links:
                try:
                    if len(index_to_skip) > 0:
                        if index in index_to_skip:
                            continue

                    if dao.is_article_exist_on_db(dates[date_index]):
                        # 既に記事がDBに保存されていたら、以後の処理を中止する
                        self.__log_file.log_warning(
                            u'Specified date article is already stored,' +
                            u'so subsequent processing is canceled.')
                        do_loop = False
                        break

                    # トランザクションを開始する
                    dao.begin_transaction()

                    # 相対パスを絶対パスへ変換
                    url = self._convert_relative_url_to_absolute_url(
                        url, a.attrib[u'href'])

                    # ポーラブログの本文を取得
                    title, text, image_urls = self.__get_pole_blog_contents(url)

                    # 女の子リストを取得
                    girls = self._get_girls(text)

                    # DBのBlogの本文を更新
                    blog_id = dao.update_blog_table(
                        dates[date_index], title, text, url)

                    # DBのT_girlを更新
                    dao.update_girl_table(dates[date_index], girls)
                    
                    # DBのT_girlsListを更新
                    girlsListId = dao.update_girls_list(blog_id, girls)

                    saved_image_file_list = []
                    if is_save_image:
                        # 画像をファイルに保存する
                        saved_image_file_list = \
                            self.__save_pole_blog_image_to_file(blog_id, image_urls)

                    # DBに画像の情報を保存する
                    dao.update_image_table(saved_image_file_list)

                    date_index += 1

                    # コミットする
                    dao.commit()

                except Exception as e:
                    # ロールバックする
                    dao.rollback()

                    errorText = u''
                    for arg in e.args:
                        errorText += arg  
                    self.__log_file.log_fatal(errorText)
                    raise e

                index += 1
                # 待機
                time.sleep(self._crawl_delay)

            # 次のページのURLを取得する
            url = self.get_next_page_url(url, html)
            if len(url) == 0:
                do_loop = False

        self.__log_file.log_function(u'Leave')

## ポーラブログのスクレイピング機能を定義するクラス
#  
class poleBlogScraper:
    ## コンストラクタ
    #  @param   self                    [in]    The object pointer.
    #  @param   log_file                [in]    ログファイルオブジェクト
    #  @param   mail_image_width        [in]    メール通知する際のメール内の画像の幅
    #
    def __init__(self, log_file, mail_image_width):
        log_file.log_function(u'Enter')

        self.__log_file = log_file
        self.__mailImageWidth__ = mail_image_width

        log_file.log_function(u'Leave')

    ## デストラクタ
    #  @param   self                    [in]    The object pointer.
    def __del__(self):
        pass

    ## メール未通知の記事検索処理
    #  @details 引数で指定された期間内で、メール未通知の記事があるかを検索する。
    #  @param   self        [in]    The object pointer.
    #  @param   dao         [in]    SQLITE3のDAOオブジェクト
    #  @param   date_from   [in]    検索期間（開始）
    #  @param   date_to     [in]    検索期間（終了）
    #  @return  is_exist_article:True：未通知の記事がある、False：未通知の記事がない
    #           __blog_id:未通知の記事がある場合のblog_id
    #
    def is_exist_unnotified_article(self, dao, date_from, date_to):
        self.__log_file.log_function(u'Enter')
        self.__log_file.log_info(u'dateFrom:{} dateTo:{}'.format(date_from, date_to))

        self.__blog_id = 0
        self.__title = u''
        self.__contents = u''
        self.__girls_list = []
        # 通知していない記事がないかDBを検索
        self.is_exist_article, self.date, self.__blog_id, self.__title, \
            self.__contents, self.__girls_list = \
                dao.find_unnotified_article(date_from, date_to)
        
        self.__log_file.log_function(u'Leave')
        return self.is_exist_article, self.__blog_id

    ## 推しの出勤状況確認処理
    #  @details 推しメンが出勤かを確認する。
    #  @param   self        [in]    The object pointer.
    #  @param   recommended_grils_list  [in]    推しのリスト（list）
    #  @return  True：推しメンがいる、False：推しメンがいない 
    #
    def __is_recommended_girl_found(self, recommended_grils_list):
        self.__log_file.log_function(u'Enter')

        isGirlFound = False
        for girl in recommended_grils_list:
            if girl in self.__girls_list:
                self.__log_file.log_info(u'{} found.'.format(girl))
                isGirlFound = True
        
        self.__log_file.log_function(u'Leave')
        return isGirlFound

    ## 通知メールの本文作成処理
    #  @details 通知メールの本文（HTMLメール）を作成する。
    #  @param   self    [in]    The object pointer.
    #  @param   dao     [in]    SQLITE3のDAOオブジェクト
    #  @param   recommended_grils_list  [in]    推しのリスト（list）
    #  @param   date    [in]    通知するブログ記事の日時
    #  @param   title   [in]    通知するブログ記事のタイトル
    #  @param   text    [in]    通知するブログ記事の本文
    #  @return  subject：メールのタイトル@n
    #           body：メールの本文
    #
    def __createHtmlMailBody__(self, dao, recommended_grils_list, date, title, text):
        self.__log_file.log_function(u'Enter')

        imageUrlList = dao.getImageUrlsFromBlogId(self.__blog_id)
        # メールに画像のリンクを埋め込む
        imgTag = u''
        for url in imageUrlList:
            imgTag += u"<div><img src='{}' width='{}'></img></div>".\
                format(url, self.__mailImageWidth__)

        # 本文の改行を<br>に置換
        text = text.replace(u'\n', u'<br>')
        body = u'<!DOCTYPE html><html><head><meta charset="UTF-8"></head>\
            <body><div><strong>{} {}</strong></div><br><div>{}</div><br>{}</body></html>'.\
                format(title, date, text, imgTag)

        # 推しが出勤か調べる
        isGirlFound = self.__is_recommended_girl_found(recommended_grils_list)

        # メールタイトルを設定する    
        subject = u''
        subject = u'{0:%Y/%m/%d}'.format(
            datetime.strptime(self.date, BLOG_DATE_FORMAT))
        if isGirlFound:
            # 推しがいる
            subject += u' ○ '
        else:
            # 推しがいない
            subject += u' × '
        subject += u' '.join(self.__girls_list)

        self.__log_file.log_function(u'Leave')
        return subject, body

    # メールのsubjectとbody(HTML形式)を取得する
    ## 通知メール取得処理
    #  @details 通知メールのタイトルと本文（HTMLメール）を取得する。
    #  @param   self                    [in]    The object pointer.
    #  @param   dao                     [in]    SQLITE3のDAOオブジェクト
    #  @param   recommended_girls_id    [in]    推しメンのリスト(list)
    #  @return  subject：メールのタイトル@n
    #           body：メールの本文
    #  @remarks is_exist_unnotified_article()の戻り値がTrueの場合に本関数をコールすること。
    #
    def get_html_mail(self, dao, recommended_girls_id):
        self.__log_file.log_function(u'Enter')

        subject = u''
        body = u''
        if self.is_exist_article:
            subject, body = self.__createHtmlMailBody__(dao, recommended_girls_id, self.date
                , self.__title, self.__contents)

        self.__log_file.log_function(u'Leave')
        return subject, body
