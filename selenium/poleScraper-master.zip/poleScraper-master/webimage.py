## @package webimage
#
#  Web上の画像ファイル取得する機能のパッケージ
#
import os
import re

import requests

## Web上の画像取得機能を定義するクラス
#
class WebImage:
    ## コンストラクタ
    #  @param   self                [in]    The object pointer.
    #  @param   log_file            [in]    ログファイルオブジェクト
    #
    def __init__(self, log_file):
        log_file.log_function(u'Enter')

        self.__log_file = log_file

        log_file.log_function(u'Leave')

    ## デストラクタ
    #  @param   self    [in]    The object pointer.
    #
    def __del__(self):
        pass

    ## 画像ファイル取得処理
    #  @details 引数で指定されたURLから画像ファイル名を返す。
    #  @param   self    [in]    The object pointer.
    #  @param   url     [in]    画像ファイルのURL
    #  @return  引数で指定された画像ファイルのurl中のファイル名部分
    #
    def get_image_file_name(self, url):
        self.__log_file.log_function(u'Enter')

        #　ファイル名を抽出
        url_list = url.split(u"/")
        file_name = re.match(r'.+\.\w+', url_list[len(url_list)-1])
        file_name = file_name.group()
        self.__log_file.log_info(u'fileName:{}'.format(file_name))

        self.__log_file.log_function(u'Leave')
        return file_name

    ## 画像ファイル拡張子取得処理
    #  @details 引数で指定されたURLからファイルの拡張子を返す。
    #  @param   self    [in]    The object pointer.
    #  @param   url     [in]    画像ファイルのURL
    #  @return  引数で指定された画像ファイルのurl中のファイルの拡張子部分
    #
    def get_image_file_extension(self, url):
        self.__log_file.log_function(u'Enter')

        root, extension = os.path.splitext(self.get_image_file_name(url))
        self.__log_file.log_debug(u'root {} extension{}'.format(root, extension))
        
        self.__log_file.log_function(u'Leave')
        return extension

    ## 画像ファイル拡張子取得処理
    #  @details 引数で指定されたURLの画像ファイルを、引数で指定されたパスに保存する。
    #  @param   self        [in]    The object pointer.
    #  @param   url         [in]    保存する画像のURL
    #  @param   file_path   [in]    画像の保存先ファイルパス
    #
    def save_image(self, url, file_path):
        self.__log_file.log_function(u'Enter')
        self.__log_file.log_info(u'filePath:{}'.format(file_path))

        # 画像をダウンロード
        self.image = requests.get(url).content

        dir = os.path.dirname(file_path)
        # 画像の保存フォルダがなければ作成する
        if not os.path.exists(dir):
            os.mkdir(dir)

        # 既にファイルがある場合は上書きしない
        if not os.path.exists(file_path):
            # 画像ファイルを保存
            with open(file_path, u"wb") as f:
                f.write(self.image)

        self.__log_file.log_function(u'Leave')
