## @package log
#
#  ログ機能のパッケージ
#
import inspect
import os
from datetime import datetime
from enum import IntEnum, auto

## ログレベルを定義するクラス
#  ロググラスで使用するログレベルを定義する。
#
class logLevel(IntEnum):
    ## ログ出力なし
    NONE        =   0
    ## 致命的エラー
    FATAL       =   auto()
    ## エラー
    ERROR       =   auto()
    ## 警告
    WARNING     =   auto()
    ## 情報
    INFO        =   auto()
    ## 関数の出入り
    FUNCTION    =   auto()
    ## デバッグ
    DEBUG       =   auto()

## ログクラス
#  ログをファイルに出力する。
#
class log():
    ## コンストラクタ
    #  @details ログファイルを保存するフォルダがなければ作成し、ログファイルをオープンする。
    #  @param   self                [in]    The object pointer.
    #  @param   log_file_path       [in]    ログファイルのパス
    #  @param   log_level           [in]    ログレベル(logLevelクラスの定義を使用する)
    #  @param   log_rotate_count    [in]    ログローテートの回数
    #  @param   max_log_size        [in]    ログファイルの最大サイズ
    #  @remarks 引数で指定されたlog_levelより低いレベルのログは出力しない。@n
    #           ログのローテートは起動時のみ行う。@n
    #           （途中でローテートすると、ログを見にくいため）
    #
    def __init__(self, log_file_path, log_level, log_rotate_count, max_log_size):
        ## ログファイルのパス
        self.__log_file_path = log_file_path
        #  ログレベル
        self.__log_level = log_level
        ## ログローテートの回数
        self.__log_rotate_count = log_rotate_count
        ## ログファイルの最大サイズ
        self.__max_log_size = max_log_size

        # ログファイルの保存フォルダがなければ作成する
        log_dir = os.path.dirname(self.__log_file_path)
        if not os.path.exists(log_dir):
            os.mkdir(log_dir)

        # ログをローテートする
        if self.__is_log_rotate_needed():
            self.__rotate_log()

        # ログファイルをオープンする
        ## ログファイルオブジェクト
        self.log_file = open(self.__log_file_path, u"at", encoding='utf-8')

    ## デストラクタ
    #  @details ログファイルをクローズする。
    #  @param   self    [in]    The object pointer.
    #
    def __del__(self):
        self.log_file.close()

    ## デストラクタ
    #  @details 指定されたファイルサイズ以上かチェックする。
    #  @param   self    [in]    The object pointer.
    #  @return  True:要ローテート、False：ローテート不要
    #  @remarks コンストラクタで指定されたログファイルの最大サイズより大きければ、
    #           ローテートが必要とする。
    #
    def __is_log_rotate_needed(self):
        if os.path.exists(self.__log_file_path):
            size = os.path.getsize(self.__log_file_path)
            if size > self.__max_log_size:
                return True
        return False

    ## デストラクタ
    #  @details ログファイルをローテートする。
    #  @param   self    [in]    The object pointer.
    #  @remarks xxx.log ⇒ xxx.log.1、xxx.log.1 ⇒ xxx.log.2のようにローテートする。@n
    #           一番古いログファイルは削除する。
    def __rotate_log(self):
        log_dir = os.path.dirname(self.__log_file_path)
        log_file_name  = os.path.basename(self.__log_file_path)
        # 後ろのログファイルから処理する
        for i in reversed(range(self.__log_rotate_count)):
            dst_file_path = os.path.join(log_dir, u'{}.{}'.\
                format(log_file_name, i + 1))
            if i == 0:
                # 1個次のファイルにリネームする
                os.rename(self.__log_file_path, dst_file_path)
            else:
                if (i + 1) == self.__log_rotate_count:
                    # 最後のファイルは削除する
                    if os.path.exists(dst_file_path):
                        os.remove(dst_file_path)

                src_file_path = os.path.join(log_dir, u'{}.{}'.\
                    format(log_file_name, i))
                if os.path.exists(src_file_path):
                    # 1個次のファイルにリネームする
                    os.rename(src_file_path, dst_file_path)

    ## 位置取得処理
    #  @details コード上での情報（ファイル名、関数名、ライン）を取得する。
    #  @param   self    [in]    The object pointer.
    #  @param   depth   [in]    コールスタック上の深さ
    #  @return  ファイル名、関数名、ライン
    #
    def __location(self, depth = 0):
        frame = inspect.stack()[depth][0] #inspect.currentframe().f_back
        return os.path.basename(frame.f_code.co_filename), frame.f_code.co_name, \
            u'line {}'.format(frame.f_lineno)

    ## ログ出力処理
    #  @details 指定されたログレベルのテキストをログファイルに書き込む。
    #  @param   self    [in]    The object pointer.
    #  @param   level   [in]    ログレベル
    #  @param   text    [in]    ログの内容
    #  @remarks コンストラクタで指定されたログレベル以下のログを出力する。@n
    #           ログファイルへはタブ区切りで出力する。
    #
    def writeText(self, level, text):
        date = u'{0:%Y/%m/%d %H:%M:%S.%f}'.format(datetime.now())
        if not self.log_file.closed:
            # SQLにコンマが含まれるため、タブ区切りで保存する
            self.log_file.write(u'{}\t{}\t {}\t{}\n'.format(date,
                self.__getLogLevelAsString(level), text, u'\t'.join(self.__location(3))))

    ## ログレベル取得処理
    #  @details ログレベルを文字列で返す。
    #  @param   self    [in]    The object pointer.
    #  @param   level   [in]    ログレベル
    #  @return  ログレベルの文字列
    #
    def __getLogLevelAsString(self, level):
        level_string = u''
        if level == logLevel.FATAL:
            level_string = u'FATAL'
        elif level == logLevel.ERROR:
            level_string = u'ERROR'
        elif level == logLevel.WARNING:
            level_string = u'WARNING'
        elif level == logLevel.INFO:
            level_string = u'INFO'
        elif level == logLevel.FUNCTION:
            level_string = u'FUNCTION'
        elif level == logLevel.DEBUG:
            level_string = u'DEBUG'
        return level_string

    ## FATALレベルのログ出力処理
    #  @param   self    [in]    The object pointer.
    #  @param   text    [in]    ログファイルに出力する文字列
    #  @remarks コンストラクタで指定したログレベルより低い場合は、ファイルに出力しない。
    #
    def log_fatal(self, text):
        if self.__log_level >= logLevel.FATAL:
            self.writeText(logLevel.FATAL, text)

    ## ERRORレベルのログ出力処理
    #  @param   self    [in]    The object pointer.
    #  @param   text    [in]    ログファイルに出力する文字列
    #  @remarks コンストラクタで指定したログレベルより低い場合は、ファイルに出力しない。
    #
    def log_error(self, text):
        if self.__log_level >= logLevel.ERROR:
            self.writeText(logLevel.ERROR, text)

    ## WARNINGレベルのログ出力処理
    #  @param   self    [in]    The object pointer.
    #  @param   text    [in]    ログファイルに出力する文字列
    #  @remarks コンストラクタで指定したログレベルより低い場合は、ファイルに出力しない。
    #
    def log_warning(self, text):
        if self.__log_level >= logLevel.WARNING:
            self.writeText(logLevel.WARNING, text)

    ## INFOレベルのログ出力処理
    #  @param   self    [in]    The object pointer.
    #  @param   text    [in]    ログファイルに出力する文字列
    #  @remarks コンストラクタで指定したログレベルより低い場合は、ファイルに出力しない。
    #
    def log_info(self, text):
        if self.__log_level >= logLevel.INFO:
            self.writeText(logLevel.INFO, text)

    ## FUNCTIONレベルのログ出力処理
    #  @param   self    [in]    The object pointer.
    #  @param   text    [in]    ログファイルに出力する文字列
    #  @remarks コンストラクタで指定したログレベルより低い場合は、ファイルに出力しない。
    #
    def log_function(self, text):
        if self.__log_level >= logLevel.FUNCTION:
            self.writeText(logLevel.FUNCTION, text)

    ## DEBUGレベルのログ出力処理
    #  @param   self    [in]    The object pointer.
    #  @param   text    [in]    ログファイルに出力する文字列
    #  @remarks コンストラクタで指定したログレベルより低い場合は、ファイルに出力しない。
    #
    def log_debug(self, text):
        if self.__log_level >= logLevel.DEBUG:
            self.writeText(logLevel.DEBUG, text)
