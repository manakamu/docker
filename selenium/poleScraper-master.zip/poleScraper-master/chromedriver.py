## @package chromedriver
#
#  ChromeDriver機能のパッケージ
#
from selenium import webdriver

## ChromeDriver機能を定義するクラス
#
class ChromeDriver:
    ## コンストラクタ
    #  @param   self                [in]    The object pointer.
    #  @param   log_file            [in]    ログファイルオブジェクト
    #  @param   chrome_driver_path  [in]    ChromeDriverのパス
    #
    def __init__(self, log_file, chrome_driver_path):
        log_file.log_function(u'Enter')

        self.__log_file = log_file
        self.__chrome_driver_path = chrome_driver_path

        log_file.log_function(u'Leave')
    
    ## デストラクタ
    #  @details ChromeDriverをCloseする。
    #  @param   self    [in]    The object pointer.
    #
    def __del__(self):
        self.__log_file.log_function(u'Enter')
        
        self.__close()
        
        self.__log_file.log_function(u'Leave')

    ## ChromeDriver取得処理
    #  @details Chromeを起動し、ChromeDriverのwebdriverを返す。
    #  @param   self    [in]    The object pointer.
    #  @return  ChromeDriverのwebdriver
    #  @remarks Chromeをheadlerss(GUI表示なし)で起動する。
    #
    def getWebDriver(self):
        self.__log_file.log_function(u'Enter')

        # Chromeの画面を表示しないように設定
        options = webdriver.ChromeOptions()
        options.add_argument(u'--headless')
        options.add_argument(u'disable-infobars');
        options.add_argument(u'--disable-extensions');
        options.add_argument(u'--disable-gpu');
        options.add_argument(u'--disable-dev-shm-usage');
        options.add_argument(u'--no-sandbox');

        # ChromeDriverを起動する
        self.__web_driver = webdriver.Chrome(self.__chrome_driver_path, options=options)
        # 要素が見つかるまで、最大10秒間待機する
        self.__web_driver.implicitly_wait(10)

        self.__log_file.log_function(u'Leave')
        return self.__web_driver

    ## ChromeDriver終了処理
    #  @details webdriverを終了する。
    #  @param   self    [in]    The object pointer.
    #
    def __close(self):
        self.__log_file.log_function(u'Enter')

        if self.__web_driver:
            self.__web_driver.close()
            self.__web_driver.quit()
            self.__web_driver = None

        self.__log_file.log_function(u'Leave')