## @package sqlite3dao
#
#  SQLite3アクセス機能のパッケージ
#
import sqlite3

## SQLite3アクセス機能を定義するクラス
#  @remarks 特定DBに依存する機能は派生クラスに実装する。
#  
class Sqlite3Dao:
    ## コンストラクタ
    #  @param   self                [in]    The object pointer.
    #  @param   log_file            [in]    ログファイルオブジェクト
    #  @param   db_file_path        [in]    DBファイルのパス
    #  @param   db_isolation_level  [in]    DBの排他モード
    #  @remarks SQLite3は排他モードで設定する。@n
    #           また、列名でアクセスできるように設定する。
    #
    def __init__(self, log_file, db_file_path, db_isolation_level):
        log_file.log_function(u'Enter')

        self.__log_file = log_file
        self._conn = sqlite3.connect(db_file_path, isolation_level = db_isolation_level)
        # 列の名前でアクセスできるようにする
        self._conn.row_factory = sqlite3.Row
        
        log_file.log_function(u'Leave')

    ## デストラクタ
    #  @details DBをクローズする
    #  @param   self    [in]    The object pointer.
    #
    def __del__(self):
        self.__log_file.log_function(u'Enter')

        if self._conn:
            # DBをCloseする
            self._conn.close()
            self._conn = None

        self.__log_file.log_function(u'Leave')

    ## トランザクション開始処理
    #  @details DBのトランザクションを開始する
    #  @param   self    [in]    The object pointer.
    #
    def begin_transaction(self):
        self.__log_file.log_function(u'Enter')

        if self._conn:
            self._conn.execute(u'begin')

        self.__log_file.log_function(u'Leave')

    ## コミット処理
    #  @details DBをコミットする
    #  @param   self    [in]    The object pointer.
    #
    def commit(self):
        self.__log_file.log_function(u'Enter')

        self._conn.commit()

        self.__log_file.log_function(u'Leave')

    ## ロールバック処理
    #  @details DBをロールバックする
    #  @param   self    [in]    The object pointer.
    #
    def rollback(self):
        self.__log_file.log_function(u'Enter')

        self._conn.rollback()

        self.__log_file.log_function(u'Leave')

    ## テーブル作成処理
    #  @details 指定されたテーブルがなければ、DBにテーブルを作成する
    #  @param   self        [in]    The object pointer.
    #  @param   table_name  [in]    テーブル名
    #　@param   row_list    [in]    テーブルに作成する列名（list）
    #
    def _create_table(self, table_name, row_list):
        self.__log_file.log_function(u'Enter')

        cursor = self._conn.cursor()
        sql = u'create table if not exists {} ({})'.format(table_name, ', '.join(row_list))
        cursor.execute(sql)

        self.__log_file.log_function(u'Leave')

    ## レコード追加処理
    #  @details DBにレコードを追加する
    #  @param   self            [in]    The object pointer.
    #  @param   table_and_row   [in]    テーブル名と列名
    #　@param   column_data     [in]    追加するレコード（tupleのlist）
    #  @remarks 引数column_dataはtupleのlistのため、複数のレコードを一度に追加することが可能
    #
    def _insert_columnToDB(self, table_and_row, column_data):
        self.__log_file.log_function(u'Enter')
        
        cursor = self._conn.cursor()
        # values(?, ?, ..., ?)の書式を作成する（?の個数が可変）
        values = u'values('
        for i in range(len(column_data[0])):
            values += u'?'
            if i != len(column_data[0]) - 1:
                values += u', '
        values += u')'
        sql = u'insert into {} {}'.format(table_and_row, values)
        self.__log_file.log_info(u'sql:{}'.format(sql))
        cursor.executemany(sql, column_data)

        self.__log_file.log_function(u'Leave')

    # 指定されたテーブルのレコード数を返す(Where句は省略可能)
    ## レコード数取得処理
    #　指定されたテーブルのレコード数を返す。
    #  @param   self            [in]    The object pointer.
    #  @param   table_name      [in]    レコード数を取得するテーブルのテーブル名
    #  @param   where_phrase    [in]    レコード数を取得する際のWhere句（省略可）
    #  return レコード数
    #
    def _get_count__(self, table_name, where_phrase = None):
        self.__log_file.log_function(u'Enter')

        cursor = self._conn.cursor()
        sql = u'select count(*) as count from {}'.format(table_name)
        if where_phrase:
            sql += u' where {}'.format(where_phrase)
        self.__log_file.log_info(u'sql:{}'.format(sql))
        cursor.execute(sql)

        row = cursor.fetchone()
        count = row['count']
        self.__log_file.log_info(u'count:{}'.format(count))

        self.__log_file.log_function(u'Leave')
        return count