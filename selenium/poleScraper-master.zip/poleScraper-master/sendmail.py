## @package log
#
#  メール送信機能のパッケージ
#
import email.message
import smtplib
from email.mime.text import MIMEText

## メール送信機能を定義するクラス
#  
class SendMail:
    ## コンストラクタ
    #  @param   self                [in]    The object pointer.
    #  @param   log_file            [in]    ログファイルオブジェクト
    #  @param   account             [in]    メールサーバのアカウント
    #  @param   password            [in]    メールサーバのパスワード
    #  @param   smptServer          [in]    メールサーバ
    #  @param   port                [in]    メールサーバのポート
    #
    def __init__(self, log_file, account, password, smptServer, port):
        log_file.log_function(u'Enter')

        self.__log_file = log_file
        self.__account = account
        self.__password = password
        self.__smptServer = smptServer
        self.__port = port

        log_file.log_function(u'Leave')

    ## デストラクタ
    #  @param   self    [in]    The object pointer.
    def __del__(self):
        pass

    ## メールMessage作成処理
    #  @details メール送信するためのMessageオブジェクトを生成する
    #  @param   self        [in]    The object pointer.
    #  @param   to_address  [in]    宛先メールアドレス
    #  @param   subject     [in]    メールタイトル
    #  @param   text        [in]    メール本文
    #  @param   subtype     [in]    メール本文の形式（plain/html）
    #  @param   charset     [in]    メール本文の文字コード
    # 
    def __create_message(self, to_address, subject, text, subtype, charset):
        self.__log_file.log_function(u'Enter')
        self.__log_file.log_info(u'toAddress:{} subject:{}'.\
            format(to_address, subject))

        message = email.message.Message()
        message = MIMEText(text, subtype, charset)
        message[u'Subject'] = subject
        message[u'From'] = self.__account
        message[u'To'] = to_address
        message.add_header(u'Content-Type', u'text/{}'.format(subtype))

        self.__log_file.log_function(u'Leave')
        return message

    ## メール送信処理
    #  @details メール送信する
    #  @param   self            [in]    The object pointer.
    #  @param   to_address      [in]    宛先メールアドレス
    #  @param   subject         [in]    メールタイトル
    #  @param   text            [in]    メール本文
    #  @param   subtype         [in]    メール本文の形式（plain/html）
    #  @param   charset         [in]    メール本文の文字コード
    # 
    def send(self, to_address, subject, text, subtype = u'plain', charset = u'utf-8'):
        self.__log_file.log_function(u'Enter')
        self.__log_file.log_info(u'toAddress:{} subject:{}'.format(u', '.join(to_address), subject))

        message = self.__create_message(to_address, subject, text, subtype, charset)
        smtp = smtplib.SMTP(self.__smptServer, self.__port)
        smtp.ehlo()
        smtp.starttls()
        smtp.ehlo()
        smtp.login(self.__account, self.__password)
        smtp.sendmail(self.__account, to_address, message.as_string())
        smtp.close()

        self.__log_file.log_function(u'Leave')
