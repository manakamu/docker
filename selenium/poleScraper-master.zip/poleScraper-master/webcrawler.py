## @package webcrawler
#
#  WEB巡回機能のパッケージ
#
from chromedriver import ChromeDriver
import lxml.html
from urllib.parse import urljoin

## WEB巡回機能のクラス
#  WEB巡回機能の基本クラス
#  @remarks 特定ページに依存する機能は派生クラスに実装する。
#
class WebCrawler:
    ## コンストラクタ
    #  @param   self                [in]    The object pointer.
    #  @param   log_file            [in]    ログファイルオブジェクト
    #  @param   chrome_driver_path  [in]    ChromeDriverのパス
    #  @param   crawl_delay         [in]    WEB巡回する際の遅延時間（ウェイト時間）
    #
    def __init__(self, log_file, chrome_driver_path, crawl_delay):
        log_file.log_function(u'Enter')

        self.__log_file = log_file
        self._crawl_delay = crawl_delay
        # WebDriverを取得
        self.__chrome_driver = ChromeDriver(self.__log_file, chrome_driver_path)
        self.__web_driver = self.__chrome_driver.getWebDriver()

        log_file.log_function(u'Leave')

    ## デストラクタ
    #  @param   self    [in]    The object pointer.
    #
    def __del__(self):
        pass

    ## HTML取得処理
    #  @details 引数で指定されたURLのHTMLを返す。
    #  @param   self    [in]    The object pointer.
    #  @param   url     [in]    HTMLを取得するURL
    #  @return  引数で指定されたURLのHTML
    #
    def _get_html(self, url):
        self.__log_file.log_function(u'Enter')
        self.__log_file.log_info(u'url:{}'.format(url))

        # URLからページを取得
        self.__web_driver.get(url)

        self.__log_file.log_function(u'Leave')
        # HTMLをParse
        return lxml.html.fromstring(self.__web_driver.page_source)

    ## 相対URLの絶対URLへの変換処理
    #  @details 引数で指定された相対URLを絶対URLに変換する。
    #  @param   self            [in]    The object pointer.
    #  @param   base_url        [in]    ベースURL
    #  @param   retative_url    [in]    変換する相対URL
    #  @return  引数で指定された相対URLの絶対URL
    #
    def _convert_relative_url_to_absolute_url(self, base_url, retative_url):
        self.__log_file.log_function(u'Enter')
        
        absolute_url = urljoin(base_url, retative_url)
        self.__log_file.log_info(u'startUrl:{} retativeUrl:{} absoluteUrl:{}'.format(
            base_url, retative_url, absolute_url))
        
        self.__log_file.log_function(u'Leave')
        return absolute_url
