from django.apps import AppConfig


class PoleConfig(AppConfig):
    name = 'pole'
