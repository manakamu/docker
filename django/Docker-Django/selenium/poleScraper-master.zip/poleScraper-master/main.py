import datetime
import glob
import os
import re
import subprocess
import sys
import traceback

from log import log, logLevel
from poleblog import poleBlogCrawler, poleBlogDao, poleBlogScraper
from sendmail import SendMail

if os.name == 'nt':
    from config_windows import *
else:
    from config_linux import *

# 定数定義
## クローリングを開始するURL
START_URL = u'https://ameblo.jp/pole-mama/entrylist.html'

## 女の子を探す際の正規表現のパターン(～☆または☆～を探す)
GIRLS_NAME_PETTERN = re.compile(
    # (ひらがな／カタカナ)☆(ひらがな／カタカナ)または☆(ひらがな／カタカナ)を探す
    r'(?:(?:[\u3040-\u3098]{2,}|[\u30a1-\u30fa\u30fc]{2,})☆){2,}(?:[\u3040-\u3098]{2,}|[\u30a1-\u30fa\u30fc]{2,}){0,}'
)
    
## 女の子リストの区切り文字
GIRLS_NAME_DELIMITER = u'☆'

## 保存する画像の拡張子（複数可）
IMAGE_EXT_TO_SAVE = [u'.jpg', ]
## メールサーバのアカウント
MAIL_ACCOUNT = u'nasmanager55@gmail.com'
## メールサーバのパスワード
MAIL_PASSWORD = u'lzmm oqxj uypj wauh'
## SMTP Server
SMTP_SERVER = u'smtp.gmail.com'
## SMTPのポート
SMTP_PORT = 587
## メールに埋め込む画像のサイズ（幅）
MAIL_IMAGE_WIDTH = 300
## クロールする際の待機時間（秒）
CRAWL_DELAY = 1

## ログのローテートの設定
LOG_ROTATE = 5
## ログの最大サイズ(Byte)
LOG_MAX_FILE_SIZE = 1 * 1024 * 1024
## ブログの画像ファイルの保存をするかどうかの設定
ENABLE_SAVE_IMAGE = True
## 管理者のメールアドレス（エラー発生時に通知する）
ADMIN_MAIL_ADDRESS = [u'manakamu2012@gmail.com']
# 動作ログ(T_log)を保存しておく日数
KEEP_LOG_DAYS = 14

# ログオブジェクト
log_file = log(LOG_FILE_PATH, logLevel.DEBUG, LOG_ROTATE, LOG_MAX_FILE_SIZE)

## メイン関数
#
def main():
    try:
        log_file.log_function(u'Enter')

        # 排他モードでDBを使用する
        dao = poleBlogDao(log_file, SQLITE3_DB_FILE, u'EXCLUSIVE')
        # テーブルがなければ作成する
        dao.create_db_table()

        # チェック開始をDBに残す
        dao.write_log_to_db(0)

        crawler = poleBlogCrawler(
            log_file, CHROME_DRIVER_PATH, CRAWL_DELAY, GIRLS_NAME_PETTERN,
            GIRLS_NAME_DELIMITER, IMAGE_PATH, IMAGE_EXT_TO_SAVE)
        # ポーラブログの内容をDBに保存する
        crawler.save_pole_blog(dao, START_URL, ENABLE_SAVE_IMAGE)

        scraper = poleBlogScraper(log_file, MAIL_IMAGE_WIDTH)
        # 本日の記事のみ検索する
        today = datetime.datetime.now()
        date_from = u'{0:%Y-%m-%d 00:00:00}'.format(today)
        date_to = u'{0:%Y-%m-%d 23:59:59}'.format(today)
        #date_from = u'2020-01-01 00:00:00' # デバッグ用
        # メール未通知の記事がないかチェック（本日分の記事のみ）
        isExistAricle, blogId = scraper.is_exist_unnotified_article(
            dao, date_from, date_to
        )
        if isExistAricle:
            # メール未通知の記事があれば、メール通知する
            mailer = SendMail(log_file, MAIL_ACCOUNT, MAIL_PASSWORD, SMTP_SERVER, SMTP_PORT)
            subject = u''
            body = u''
            mail_list = dao.get_mail_list()
            for mail in mail_list:
                subject, body = scraper.get_html_mail(dao, mail[1])
                # メール送信
                mailer.send(mail[0], subject, body, u'html')

            # DBの通知済みフラグをセットする
            dao.setNotifiedFlag(blogId)
            # メール送信をDBに残す
            dao.write_log_to_db(2, None, blogId)

        # 画像ファイルのサムネイルを作成する
        create_image_thumbnail(IMAGE_PATH, os.path.join(IMAGE_PATH, u'thumb'))

        # チェック完了をDBに残す
        dao.write_log_to_db(1)

        # T_logの古いログを削除する
        specific_datetime = datetime.datetime.today() - datetime.timedelta(days=KEEP_LOG_DAYS)
        dao.cleanup_log(specific_datetime)

    except Exception as e:
        trace = traceback.format_exc()
        log_file.log_fatal(e.args)
        log_file.log_fatal(trace)

        print(traceback.format_exc())

        # チェック完了をDBに残す
        dao.write_log_to_db(1, e.args)

        # エラーメールを送信する
        mail = SendMail(log_file, MAIL_ACCOUNT, MAIL_PASSWORD, SMTP_SERVER, SMTP_PORT)
        mail.send(ADMIN_MAIL_ADDRESS, u'poleBlogScaper error notification', u'{}\n{}'.format(e.args, trace), u'plain')
    
    finally:
        log_file.log_function(u'Leave')

## サムネイル作成処理
    #  @details 指定されたフォルダのjpgのサムネイルを出力フォルダへ作成する
    #  @param   src_path        [in]    入力フォルダのパス
    #  @param   dst_path        [in]    出力フォルダのパス
    # 
def create_image_thumbnail(src_path, dst_path):
    log_file.log_function(u'Enter')
    
    if not os.path.isdir(src_path):
        log_file.log_fatal(u'Invalid soure path.{}'.format(src_path))
        return

    if not os.path.isdir(dst_path):
        os.makedirs(dst_path)

    files = glob.glob(os.path.join(src_path, u'*.jpg'))
    for file in files:
        filename = os.path.basename(file)
        if not os.path.exists(os.path.join(dst_path, filename)):
            subprocess.run([CMD_IMAGEMAGICK, file, "-resize", "200x", os.path.join(dst_path, filename)])
    log_file.log_function(u'Leave')

if __name__ == u"__main__":
    main()
