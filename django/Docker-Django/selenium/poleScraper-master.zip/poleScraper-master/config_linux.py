## ChromeDriverのパス
CHROME_DRIVER_PATH = u'/home/centos/chromedriver'

## DBファイルのパス
SQLITE3_DB_FILE = u'/home/centos/scraper/poleBlogScraper/db/poleBlog.db'

## 画像ファイルの保存先
IMAGE_PATH = u'/home/centos/scraper/poleBlogScraper/images'

## ログファイルのパス
LOG_FILE_PATH = u'/home/centos/scraper/poleBlogScraper/log/poleBlog.log'

#ImageMagickのパス
CMD_IMAGEMAGICK = u'/usr/bin/convert'